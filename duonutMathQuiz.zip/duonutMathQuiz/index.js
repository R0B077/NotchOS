const rightAnswerModal = document.querySelector("#rightAnswerModal");
const rightTextHeading = document.querySelector("#rightTextHeading");
const wrongAnswerModal = document.querySelector("#wrongAnswerModal");
const wrongTextHeading = document.querySelector("#wrongTextHeading");
const tooLateModal = document.querySelector("#wrongAnswerModal");
const tooLateTextHeading = document.querySelector("#wrongTextHeading");
const everyThingModal = document.querySelector(".everyThingModal");
const question = document.querySelector("#question");
const option1 = document.querySelector("#option1");
const option2 = document.querySelector("#option2");
const option3 = document.querySelector("#option3");
const option4 = document.querySelector("#option4");
const quiz = document.querySelector(".quiz");
const screenWidth = window.screen.width;

const wrongText = [
    "Oh, shoot. That's the wrong one you just clicked.",
    "That was pretty close. I'm sure you'll get it next time!",
    "If that isn't wrong, acorns grow out of the earth.",
    "Aw, looks like you've run out of luck. Look for a four leaf clover!",
    "You sure you clicked the right one?",
    "Every time you click a wrong one, you crack a nut :(",
]

const rightText = [
    "Amazing!",
    "Mmm, right one.",
    "We nuts do really hate nutcrackers. By the way, that's right.",
    "Exactly, that's correct.",
    "German? Korrekt. Spanish? Exacto. English? Correct.",
    "Perfect!",
] 

const tooLateText = [
    "You're late!",
    "You need to figure out the answer before the time ends!",
    "Try doing it more quickly!",
    "408RequestTimedOut",
    "Next time, do it quicker!",
] 

if (screenWidth < 425) {
    everyThingModal.style.width = "100vw";
    everyThingModal.style.height = "100vh";
    wrongTextHeading.style.fontSize = "35px";
    wrongTextHeading.style.bottom = "25px";
    rightTextHeading.style.fontSize = "35px";
    rightTextHeading.style.bottom = "25px";
}

const json = {
    "7 + 5 = ": {
        "option1": "w;iuerdjknmwuefblh",
        "option2": "whrtbfiuerdjknmwuefblh",
        "option3": "eitghfiwrbgkjj2brkgb",
        "option4": "iuerdjknmwuefblh",
        "correct": "option2"
    },
    "√16 = ": {
        "option1": "4",
        "option2": "234",
        "option3": "3",
        "option4": "7",
        "correct": "option1"
    },
    "12² = ": {
        "option1": "233",
        "option2": "876",
        "option3": "65",
        "option4": "144",
        "correct": "option4"
    },
    "184 - 71 = ": {
        "option1": "912",
        "option2": "1",
        "option3": "113",
        "option4": "75",
        "correct": "option3"
    },
    "242 * 4 = ": {
        "option1": "968",
        "option2": "4365",
        "option3": "575",
        "option4": "7565",
        "correct": "option1"
    },
    "243 ÷ 3 = ": {
        "option1": "54",
        "option2": "654",
        "option3": "43567",
        "option4": "81",
        "correct": "option4"
    },
    "∛1728 = ": {
        "option1": "9",
        "option2": "54",
        "option3": "12",
        "option4": "65",
        "correct": "option3"
    },
    "4 + 3 =": {
        "option1": "54",
        "option2": "7",
        "option3": "4",
        "option4": "23",
        "correct": "option2"
    },
    "7 - 2 = ": {
        "option1": "5",
        "option2": "54",
        "option3": "597",
        "option4": "9",
        "correct": "option1"
    }
};

const randomQuestion = Object.keys(json)[Math.floor(Math.random() * Object.keys(json).length)];
const correctAnswer = json[randomQuestion].correct;
const correct = document.querySelector(`#${correctAnswer}`);
let wrongs = [];

if (correctAnswer == "option1") {
    wrongs = [
        "option2",
        "option3",
        "option4"
    ]
} else if (correctAnswer == "option2") {
    wrongs = [
        "option1",
        "option3",
        "option4"
    ]
} else if (correctAnswer == "option3") {
    wrongs = [
        "option1",
        "option2",
        "option4"
    ]
} else if (correctAnswer == "option4") {
    wrongs = [
        "option1",
        "option2",
        "option3"
    ]
};

question.innerText = randomQuestion;
option1.innerText = json[randomQuestion].option1;
option2.innerText = json[randomQuestion].option2;
option3.innerText = json[randomQuestion].option3;
option4.innerText = json[randomQuestion].option4;

if (option1.innerText.length > 7 || option2.innerText.length > 7 || option3.innerText.length > 7 || option4.innerText.length > 7) {
    option1.innerHTML += '<br>'
    option2.innerHTML += '<br>'
    option3.innerHTML += '<br>'
    option4.innerHTML += '<br>'
}

correct.addEventListener("click", () => {
    quiz.remove();
    rightTextHeading.innerText = rightText[Math.floor(Math.random() * rightText.length)];
    rightAnswerModal.style.display = "block";
});

wrongs = wrongs.map(querySelect);

function querySelect(el) {
    return document.querySelector(`#${el}`);
};

wrongs.forEach((wrongAnswer) => {
    wrongAnswer.addEventListener("click", () => {
        quiz.remove();
        wrongTextHeading.innerText = wrongText[Math.floor(Math.random() * wrongText.length)];
        wrongAnswerModal.style.display = "block";
    });
});

function createProgressbar(id, duration, callback) {
    var progressbar = document.getElementById(id);
    progressbar.className = 'progressbar';
    var progressbarinner = document.createElement('div');
    progressbarinner.className = 'inner';
    progressbarinner.style.animationDuration = duration;
    if (typeof(callback) === 'function') {
      progressbarinner.addEventListener('animationend', callback);
    }
    progressbar.appendChild(progressbarinner);
    progressbarinner.style.animationPlayState = 'running';
  }
  
  addEventListener('load', function() {
    createProgressbar('progressbar4', '5s', function() {
        quiz.remove();
        tooLateTextHeading.innerText = tooLateText[Math.floor(Math.random() * tooLateText.length)];
        tooLateModal.style.display = "block";
    });
  });